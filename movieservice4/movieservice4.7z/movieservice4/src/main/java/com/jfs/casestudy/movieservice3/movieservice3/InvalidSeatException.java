package com.jfs.casestudy.movieservice3.movieservice3;

public class InvalidSeatException extends Exception {
	
	public InvalidSeatException(String msg)
	{
		super(msg);
	}

}
