package com.jfs.casestudy.movieservice3.movieservice3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Movieservice3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
